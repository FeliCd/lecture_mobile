# Minh chứng giao diện Lab 2 — 10/11/2026 (UTC+7)
E01: week-412.png, lịch tuần trước/sau, cùng fixture 9 buổi tuần 09–15/11.
E02: today-412.png, vị trí ô chọn học kỳ trước và nhãn kỳ sau.
E03: profile-412.png, so sánh trước/sau tại Tài khoản và cài đặt.
E04: luong-bo-sung/08-save-uncertain.png, phản hồi khi chưa chắc kết quả lưu.
E05: các ảnh *-360.png, *-412.png để kiểm hai viewport.

Nguồn trước: source Flutter từ git archive 518139c.
Nguồn sau: source Flutter commit 8298cc0.
Viewport: 360×800 và 412×900 dp. Xuất PNG tỷ lệ 2. Ảnh là dữ liệu mẫu,
không phải dữ liệu production, nghiên cứu người dùng, hoặc đầu ra Stitch/Figma.
Hình tuần được cuộn đến vùng lịch để đối chiếu cùng tác vụ.

Tái hiện: giải nén commit phù hợp; sao chép file test đính kèm thành
test/lab2_deck_capture_test.dart; điều chỉnh đường dẫn font MaterialIcons theo
Flutter SDK; flutter pub get; đặt LAB2_EVIDENCE_OUT là thư mục xuất ảnh; chạy
flutter test --no-pub test/lab2_deck_capture_test.dart
Kết quả ngày chụp: 2 test đạt ở mỗi commit. Bộ test bổ sung 14 đạt:
ux_lecturer_walkthrough_test.dart, weekly_timetable_test.dart, academic_term_test.dart.
Các nhãn trạng thái theo giờ chạy test và có thể thay đổi khi chạy lại.
